# Invasion

A simple game about defending your planet and escaping solitude.

Made within the span of 48 hours during the Ludum Dare 38 event.
